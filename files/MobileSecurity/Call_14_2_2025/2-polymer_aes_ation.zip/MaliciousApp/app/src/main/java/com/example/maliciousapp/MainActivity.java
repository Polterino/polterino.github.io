package com.example.maliciousapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MOBIOTSEC";

    public String piece_a;
    public String piece_b;
    public String key;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();
        
        piece_a = ************

        Intent askIntent = ************
        try {
            startForResult.launch(askIntent);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    ActivityResultLauncher<Intent> startForResult = registerForActivityResult(
            (ActivityResultContract) new StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent i = result.getData();
                        
                        piece_b = ************
                        Log.d(TAG, "second piece: " + piece_b);

                        key = ************
                        Log.d(TAG, "key: " + key);

                        String flag= "";
                        String cipher = ************
                        try {
                            flag = ************
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                        Log.d(TAG, flag);

                        Intent resultIntent = new Intent();
                        resultIntent.putExtra("answer", key);
                        setResult(Activity.RESULT_OK, resultIntent);
                    }
                }
            });


    private static String polymerization(String a, String b) {
      *****************************
    }

}
