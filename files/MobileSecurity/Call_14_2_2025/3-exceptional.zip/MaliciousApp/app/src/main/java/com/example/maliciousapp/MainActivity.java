package com.example.maliciousapp;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MOBIOTSEC";


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent();
        intent.setComponent(new ComponentName("******", "******"));
        intent.putExtra("******", "******");
        intent.putExtra("******", ******);
        startActivity(intent);
      
        
        /**
          Fill here the missing code
          Possible hint: this.registerReceiver(secretReceiver, new IntentFilter("com.mobiotsec.intent.action.SECRET_DELIVERY"));
          String key = log.substring(log.indexOf("copy") + <key_length>, log.indexOf("resulted") -1);

          ******
          .....
          .....
          .....        
          ******
      
        */

    }
}
