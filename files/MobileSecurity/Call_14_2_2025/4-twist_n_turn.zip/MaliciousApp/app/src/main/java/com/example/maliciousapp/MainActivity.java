package com.example.maliciousapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MOBIOTSEC";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent();
        intent.setAction("com.mobiotsec.intent.action.PULL");
        try {
            startForResult.launch(intent);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    ActivityResultLauncher<Intent> startForResult = registerForActivityResult(
            (ActivityResultContract) new StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        try {
                            Intent res_intent = result.getData();
                            String action = res_intent.getAction();
                            Intent new_intent = new Intent();
                            switch (action) {
                                case "**********":
                                    new_intent.setAction("**********");
                                    startForResult.launch(new_intent);
                                    break;
                                case "**********":
                                    new_intent.setAction("**********");
                                    startForResult.launch(new_intent);
                                    break;
                                case "**********":
                                    new_intent.setAction("**********");
                                    startForResult.launch(new_intent);
                                    break;
                                case "**********":
                                    new_intent.setAction("**********");
                                    startForResult.launch(new_intent);
                                    break;
                                case "**********":
                                    String flag = res_intent.getStringExtra("FLAG");
                                    Log.d(TAG, flag);
                                    break;
                            }
                        }
                        catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    else {
                        Log.d(TAG, "try again!");
                    }
                }
            });

}
