package com.example.maliciousapp;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult;
import androidx.activity.result.ActivityResultCallback;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MOBIOTSEC";

    ActivityResultLauncher<Intent> startForResult = registerForActivityResult(
            (ActivityResultContract) new StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == 0) {
                        String output = ************

                        Intent intent = ************

                        startForResult.launch(intent);
                    } else if (result.getResultCode() == 2) {

                        String output = ************

                        Log.d(TAG, output);
                    }
                }
            });

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = new Intent();
        intent.setComponent(new ComponentName("************", "************"));
        Bundle data = new Bundle();
        data.putString("************", "************");

        intent.putExtras(data);
        startForResult.launch(intent);
    }

}
