#!usr/bin/env python3
from scapy.all import *
import subprocess

# The following two lines are used to automatically get the name of the interface used for docker
# If it does not work, you can simply set it manually
cmd = "ip a | grep 10.9.0.1 | awk '{print $7}'"
IFACE = subprocess.run(cmd, shell=True, check=True,
                       universal_newlines=True, stdout=subprocess.PIPE).stdout.strip()

def send_reset(pkt):
	"""
	Given a sniffed packet, send a rst packet with the correct information
	"""

	src_ip = pkt[****].****
	dst_ip = pkt[****].****
	src_port = pkt[****].****
	dst_port = pkt[****].****
	ack = pkt[****].****
	seq = pkt[****].****

	ip = IP(src=****, dst=****)
	tcp = TCP(sport=****, dport=****, flags='****', seq=****)

	rst = ip/tcp
	send(rst, verbose=0, iface=IFACE)

def main():
	# Sniffing exchanged packets
	print('[+] Sniffing...')
	pkt = sniff(iface=IFACE, filter='**** **** ****', prn=send_reset)

if __name__ == '__main__':
	main()
