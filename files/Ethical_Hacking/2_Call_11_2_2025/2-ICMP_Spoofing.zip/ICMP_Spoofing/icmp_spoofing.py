#!/usr/bin/env python3
from scapy.all import *

IFACE = '****'

def spoof(pkt):
	"""
	Given a received packet, spoof its address and send a reply
	"""

	# Check if the packet is an ICMP echo request
	if pkt[****].**** == ****:

		spoof_ip = IP(src=pkt[****].****, dst=pkt[****].****)

		spoof_icmp = ICMP(type=****, id=pkt[****].****, seq=pkt[****].****)

		spoof_data = pkt[****].load
    	
		spoof_pkt = # Build the spoofed packet
		send(spoof_pkt, verbose=0)

		print('[+] Spoofed Packet Sent')
	return

print('[+] Sniffing...')
pkt = sniff(iface=IFACE, filter='****', prn=spoof)
